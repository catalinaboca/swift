var ec2_view=t_ec_2_view()
var ec2_model=t_ec_2_model()
var ec2_controller=t_ec_2_controller()
ec2_controller.rezolva()